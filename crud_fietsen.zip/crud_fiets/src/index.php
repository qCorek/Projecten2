<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php
    // functie: Programma CRUD fietsen
    // auteur: Vul hier je naam in   

    // Initialisatie
    include 'Fiets.php';
    $fiets = new Fiets;
    $fiets->crudMain();


    ?>

</body>
</html>



