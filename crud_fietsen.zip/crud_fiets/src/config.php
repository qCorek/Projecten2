<?php
// auteur: Vul hier je naam in
// functie: configuratiebestand

define("DATABASE", "fietsenmaker");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "fietsen");

?>