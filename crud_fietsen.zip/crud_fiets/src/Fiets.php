<?php


include_once "config.php";
include_once "Database.php";

class Fiets{



 // selecteer de data uit de opgeven table
 function getData($table): array {
    // Connect database
    $conn = Database::connectDb();

    // Select data uit de opgegeven table methode query
    // query: is een prepare en execute in 1 zonder placeholders
    // $result = $conn->query("SELECT * FROM $table")->fetchAll();

    // Select data uit de opgegeven table methode prepare
    $sql = "SELECT * FROM $table";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();

    return $result;
 }






 function crudMain(){

    // Menu-item   insert
    $txt = "
    <h1>Crud Fietsen</h1>
    <nav>
		<a href='insert.php'>Toevoegen nieuwe fiets</a>
    </nav><br>";
    echo $txt;

    // Haal alle fietsen record uit de tabel 
    $result = getData(CRUD_TABLE);

    //print table
    printCrudTabel($result);
    
 }
}
?>