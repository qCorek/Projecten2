# Classdiagram (technisch ontwerp)

Onderstaande klassen zijn geïmplementeerd:

- **App\Database\DatabaseConnection**
  - +pdo: PDO
  - +__construct(dsn, user, password, options)
  - +getPdo(): PDO

- **App\Domain\Product**
  - -id: ?int
  - -name: string
  - -price: float
  - +getId(): ?int
  - +getName(): string
  - +getPrice(): float
  - +withId(id): Product
  - +withName(name): Product
  - +withPrice(price): Product

- **App\Repository\ProductRepository**
  - -pdo: PDO
  - +__construct(pdo)
  - +createTable(): void
  - +create(product): Product
  - +findById(id): ?Product
  - +findAll(): Product[]
  - +update(product): void
  - +delete(id): void

Relaties:
- ProductRepository **gebruikt** PDO
- ProductRepository **maakt/leest** Product
- DatabaseConnection **levert** PDO
