# Acceptatietest verslag (CRUD)

## Doel
Controleren dat de CRUD-functies (Create, Read, Update, Delete) correct werken via de `ProductRepository` met een echte databaseverbinding (SQLite in-memory) en dat `findAll()` de actuele dataset teruggeeft.

## Testomgeving
- PHP: 8.1+ (vereist)
- Database: SQLite (in-memory) via PDO
- Testframework: PHPUnit
- Scope: Repository-laag + database (geen mocks)

## Uitgevoerde stappen
1. Database initialiseren en tabel `products` aanmaken.
2. **Create**: product aanmaken (`Laptop`, 999.95) en controleren dat een `id` is toegekend.
3. **Read**: product ophalen op id en controleren op juiste naam.
4. **Update**: prijs wijzigen naar 899.95 en opnieuw ophalen om update te verifiëren.
5. **Delete**: product verwijderen en controleren dat `findById()` daarna `null` teruggeeft.
6. **findAll**: twee producten toevoegen en controleren dat er exact 2 records terugkomen.

## Resultaat
- Alle assertions zijn geslaagd.
- Conclusie: de CRUD-functies werken end-to-end tegen PDO/SQLite.

## Bewijs
Zie screenshot in `tests/screenshots/phpunit.png`.
