<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Domain\Product;
use PHPUnit\Framework\TestCase;
use RuntimeException;
use Tests\Support\CreatesSqliteRepo;

final class ProductRepositoryTest extends TestCase
{
    use CreatesSqliteRepo;

    public function testCreatePersistsAndReturnsProductWithId(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $created = $repo->create(new Product(null, 'Pen', 1.25));

        $this->assertNotNull($created->getId());
        $this->assertSame('Pen', $created->getName());
        $this->assertSame(1.25, $created->getPrice());
    }

    public function testFindByIdReturnsNullWhenNotFound(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $this->assertNull($repo->findById(999));
    }

    public function testFindByIdReturnsProductWhenFound(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $created = $repo->create(new Product(null, 'Boek', 10.00));
        $found = $repo->findById($created->getId() ?? 0);

        $this->assertNotNull($found);
        $this->assertSame($created->getId(), $found->getId());
        $this->assertSame('Boek', $found->getName());
        $this->assertSame(10.00, $found->getPrice());
    }

    public function testFindAllReturnsAllProducts(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $repo->create(new Product(null, 'A', 1.0));
        $repo->create(new Product(null, 'B', 2.0));

        $all = $repo->findAll();
        $this->assertCount(2, $all);
        $this->assertSame('A', $all[0]->getName());
        $this->assertSame('B', $all[1]->getName());
    }

    public function testUpdateUpdatesExistingProduct(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $created = $repo->create(new Product(null, 'A', 1.0));
        $updated = $created->withName('A2')->withPrice(1.5);

        $repo->update($updated);
        $found = $repo->findById($created->getId() ?? 0);

        $this->assertSame('A2', $found?->getName());
        $this->assertSame(1.5, $found?->getPrice());
    }

    public function testUpdateThrowsWhenIdIsNull(): void
    {
        $this->expectException(RuntimeException::class);

        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $repo->update(new Product(null, 'X', 1.0));
    }

    public function testDeleteRemovesProduct(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        $created = $repo->create(new Product(null, 'A', 1.0));
        $repo->delete($created->getId() ?? 0);

        $this->assertNull($repo->findById($created->getId() ?? 0));
    }
}
