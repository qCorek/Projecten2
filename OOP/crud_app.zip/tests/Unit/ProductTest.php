<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Domain\Product;
use PHPUnit\Framework\TestCase;

final class ProductTest extends TestCase
{
    public function testGetters(): void
    {
        $p = new Product(1, 'Naam', 12.50);
        $this->assertSame(1, $p->getId());
        $this->assertSame('Naam', $p->getName());
        $this->assertSame(12.50, $p->getPrice());
    }

    public function testWithIdCreatesNewInstance(): void
    {
        $p1 = new Product(null, 'Naam', 12.50);
        $p2 = $p1->withId(10);

        $this->assertNull($p1->getId());
        $this->assertSame(10, $p2->getId());
        $this->assertSame($p1->getName(), $p2->getName());
        $this->assertSame($p1->getPrice(), $p2->getPrice());
    }

    public function testWithNameCreatesNewInstance(): void
    {
        $p1 = new Product(1, 'Oud', 1.0);
        $p2 = $p1->withName('Nieuw');

        $this->assertSame('Oud', $p1->getName());
        $this->assertSame('Nieuw', $p2->getName());
        $this->assertSame(1, $p2->getId());
    }

    public function testWithPriceCreatesNewInstance(): void
    {
        $p1 = new Product(1, 'Naam', 1.0);
        $p2 = $p1->withPrice(2.5);

        $this->assertSame(1.0, $p1->getPrice());
        $this->assertSame(2.5, $p2->getPrice());
        $this->assertSame(1, $p2->getId());
    }
}
