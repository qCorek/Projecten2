<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Database\DatabaseConnection;
use PHPUnit\Framework\TestCase;
use PDO;

final class DatabaseConnectionTest extends TestCase
{
    public function testGetPdoReturnsPdoInstance(): void
    {
        $db = new DatabaseConnection('sqlite::memory:');
        $this->assertInstanceOf(PDO::class, $db->getPdo());
    }
}
