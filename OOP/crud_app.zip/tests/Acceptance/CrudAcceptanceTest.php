<?php
declare(strict_types=1);

namespace Tests\Acceptance;

use App\Domain\Product;
use PHPUnit\Framework\TestCase;
use Tests\Support\CreatesSqliteRepo;

/**
 * Acceptatietest: voert de CRUD-flow uit zoals een gebruiker die zou gebruiken.
 */
final class CrudAcceptanceTest extends TestCase
{
    use CreatesSqliteRepo;

    public function testCrudFlow(): void
    {
        $pdo = $this->createPdo();
        $repo = $this->createRepo($pdo);

        // C
        $created = $repo->create(new Product(null, 'Laptop', 999.95));
        $this->assertNotNull($created->getId());

        // R
        $found = $repo->findById($created->getId() ?? 0);
        $this->assertSame('Laptop', $found?->getName());

        // U
        $repo->update($created->withPrice(899.95));
        $updated = $repo->findById($created->getId() ?? 0);
        $this->assertSame(899.95, $updated?->getPrice());

        // D
        $repo->delete($created->getId() ?? 0);
        $this->assertNull($repo->findById($created->getId() ?? 0));

        // lijst
        $repo->create(new Product(null, 'Muis', 19.99));
        $repo->create(new Product(null, 'Toetsenbord', 49.99));
        $all = $repo->findAll();
        $this->assertCount(2, $all);
    }
}
