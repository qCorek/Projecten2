<?php
declare(strict_types=1);

namespace Tests\Support;

use App\Repository\ProductRepository;
use PDO;

trait CreatesSqliteRepo
{
    private function createPdo(): PDO
    {
        $pdo = new PDO('sqlite::memory:');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        return $pdo;
    }

    private function createRepo(PDO $pdo): ProductRepository
    {
        $repo = new ProductRepository($pdo);
        $repo->createTable();
        return $repo;
    }
}
