<?php
declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use App\Database\DatabaseConnection;
use App\Domain\Product;
use App\Repository\ProductRepository;

// Demo: sqlite bestand in project root
$db = new DatabaseConnection('sqlite:' . __DIR__ . '/../database.sqlite');
$repo = new ProductRepository($db->getPdo());
$repo->createTable();

$product = $repo->create(new Product(null, 'Demo product', 9.99));
echo "Aangemaakt product ID: " . $product->getId() . PHP_EOL;

$found = $repo->findById($product->getId() ?? 0);
echo "Gevonden: " . ($found?->getName() ?? 'niets') . PHP_EOL;
