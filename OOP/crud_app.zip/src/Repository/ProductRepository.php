<?php
declare(strict_types=1);

namespace App\Repository;

use App\Domain\Product;
use PDO;
use RuntimeException;

final class ProductRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    public function createTable(): void
    {
        $sql = <<<SQL
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price REAL NOT NULL
);
SQL;
        $this->pdo->exec($sql);
    }

    public function create(Product $product): Product
    {
        $stmt = $this->pdo->prepare('INSERT INTO products(name, price) VALUES (:name, :price)');
        $stmt->execute([
            ':name'  => $product->getName(),
            ':price' => $product->getPrice(),
        ]);

        $id = (int)$this->pdo->lastInsertId();
        return $product->withId($id);
    }

    public function findById(int $id): ?Product
    {
        $stmt = $this->pdo->prepare('SELECT id, name, price FROM products WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();

        if ($row === false) {
            return null;
        }

        return new Product((int)$row['id'], (string)$row['name'], (float)$row['price']);
    }

    /** @return Product[] */
    public function findAll(): array
    {
        $stmt = $this->pdo->query('SELECT id, name, price FROM products ORDER BY id ASC');
        $rows = $stmt->fetchAll();

        return array_map(
            fn(array $r) => new Product((int)$r['id'], (string)$r['name'], (float)$r['price']),
            $rows
        );
    }

    public function update(Product $product): void
    {
        $id = $product->getId();
        if ($id === null) {
            throw new RuntimeException('Kan product zonder id niet updaten.');
        }

        $stmt = $this->pdo->prepare('UPDATE products SET name = :name, price = :price WHERE id = :id');
        $stmt->execute([
            ':id'    => $id,
            ':name'  => $product->getName(),
            ':price' => $product->getPrice(),
        ]);
    }

    public function delete(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM products WHERE id = :id');
        $stmt->execute([':id' => $id]);
    }
}
