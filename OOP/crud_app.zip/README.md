# CRUD app (PDO + namespaces + autoloading + tests)

## Install
```bash
composer install
```

## Run tests
```bash
composer test
```

## Demo run (optioneel)
```bash
php public/index.php
```
