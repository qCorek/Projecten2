<?php
namespace App\Model;

class Fiets
{
    private string $merk;
    private string $type;
    private float $prijs;

    public function __construct(string $merk, string $type, float $prijs)
    {
        $this->merk = $merk;
        $this->type = $type;
        $this->prijs = $prijs;
    }

    public function getMerk(): string { return $this->merk; }
    public function getType(): string { return $this->type; }
    public function getPrijs(): float { return $this->prijs; }
}
