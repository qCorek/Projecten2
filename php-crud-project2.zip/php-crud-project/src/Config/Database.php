<?php
namespace App\Config;

use PDO;

class Database
{
    public function getConnection(): PDO
    {
        return new PDO(
            "mysql:host=localhost;dbname=fietsenmaker;charset=utf8",
            "root",
            "",
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }
}
