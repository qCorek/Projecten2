<?php
namespace App\Repository;

use PDO;
use App\Model\Fiets;

class FietsRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function findAll(): array
    {
        return $this->db->query("SELECT * FROM fietsen")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create(Fiets $fiets): bool
    {
        $stmt = $this->db->prepare(
            "INSERT INTO fietsen (merk, type, prijs) VALUES (?, ?, ?)"
        );

        return $stmt->execute([
            $fiets->getMerk(),
            $fiets->getType(),
            $fiets->getPrijs()
        ]);
    }

    public function delete(int $id): bool
    {
        return $this->db
            ->prepare("DELETE FROM fietsen WHERE id = ?")
            ->execute([$id]);
    }
}
