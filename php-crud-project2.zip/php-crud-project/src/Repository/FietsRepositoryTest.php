<?php

use PHPUnit\Framework\TestCase;
use App\Config\Database;
use App\Repository\FietsRepository;
use App\Model\Fiets;

class FietsRepositoryTest extends TestCase
{
    public function testCreateFiets()
    {
        $database = new Database();
        $db = $database->getConnection();

        $repo = new FietsRepository($db);
        $fiets = new Fiets("Gazelle", "Stadsfiets", 799);

        $this->assertTrue($repo->create($fiets));
    }
}
