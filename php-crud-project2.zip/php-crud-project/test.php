<?php
require 'vendor/autoload.php';

use App\Config\Database;

$db = new Database();
echo "Autoloading werkt!";
